package ai.mangal.core.stt

import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

interface WhisperTranscriber {
    val isModelLoaded: StateFlow<Boolean>
    suspend fun loadWhisperModel(binPath: String): Result<Unit>
    fun transcribePcm16kStream(pcmSamples: FloatArray): Flow<String>
    suspend fun release()
}

@Singleton
class WhisperCppTranscriberImpl @Inject constructor() : WhisperTranscriber {
    private val _isModelLoaded = MutableStateFlow(false)
    override val isModelLoaded: StateFlow<Boolean> = _isModelLoaded.asStateFlow()

    override suspend fun loadWhisperModel(binPath: String): Result<Unit> {
        // Phase 1 scaffold contract — whisper.cpp JNI wired in Phase 3
        _isModelLoaded.value = false
        return Result.success(Unit)
    }

    override fun transcribePcm16kStream(pcmSamples: FloatArray): Flow<String> = flow {
        emit("")
    }

    override suspend fun release() {
        _isModelLoaded.value = false
    }
}

@Module
@InstallIn(SingletonComponent::class)
abstract class SttModule {
    @Binds
    @Singleton
    abstract fun bindWhisperTranscriber(impl: WhisperCppTranscriberImpl): WhisperTranscriber
}
