package ai.mangal.assistant.ui.chat

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import ai.mangal.assistant.permissions.MangalPermissionGroup
import ai.mangal.assistant.permissions.PermissionGatekeeper

@Composable
fun VoiceChatScreen() {
    val context = LocalContext.current
    var micGranted by remember {
        mutableStateOf(PermissionGatekeeper.isGroupGranted(context, MangalPermissionGroup.MICROPHONE))
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        micGranted = result.values.all { it }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "MANGAL · Offline Voice Assistant",
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    text = "Phase 1 Scaffold · Zero runtime network calls · Encrypted SQLCipher Room DB",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = if (micGranted) {
                        "Microphone permission granted. Ready for Phase 3 whisper.cpp pipeline."
                    } else {
                        "Microphone permission required for on-device STT capture."
                    },
                    style = MaterialTheme.typography.bodyMedium
                )

                if (!micGranted) {
                    OutlinedButton(
                        onClick = {
                            micPermissionLauncher.launch(
                                MangalPermissionGroup.MICROPHONE.androidPermissions.toTypedArray()
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Grant RECORD_AUDIO Permission")
                    }
                }

                Button(
                    onClick = { /* Wired in Phase 3 push-to-talk */ },
                    enabled = micGranted,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Hold to Speak (Push-to-Talk Stub)")
                }
            }
        }
    }
}
