package ai.mangal.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import ai.mangal.assistant.navigation.MangalNavHost
import dagger.hilt.android.AndroidEntryPoint

private val MangalDarkPalette = darkColorScheme()

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = MangalDarkPalette) {
                MangalNavHost()
            }
        }
    }
}
