package ai.mangal.assistant.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import ai.mangal.assistant.permissions.MangalPermissionGroup
import ai.mangal.assistant.permissions.PermissionGatekeeper

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val grantStates = remember {
        mutableStateMapOf<MangalPermissionGroup, Boolean>().apply {
            MangalPermissionGroup.entries.forEach { group ->
                put(group, PermissionGatekeeper.isGroupGranted(context, group))
            }
        }
    }

    var activeGroupPending: MangalPermissionGroup? = remember { null }
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        activeGroupPending?.let { group ->
            grantStates[group] = result.values.all { it }
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Settings & Runtime Permissions",
                style = MaterialTheme.typography.titleLarge
            )
            Text(
                text = "SQLCipher AES-256 Encrypted Room Storage · Android Native TextToSpeech",
                style = MaterialTheme.typography.bodySmall
            )

            MangalPermissionGroup.entries.forEach { group ->
                val isGranted = grantStates[group] == true
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = group.title, style = MaterialTheme.typography.titleSmall)
                        Text(text = group.rationale, style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(
                        onClick = {
                            activeGroupPending = group
                            launcher.launch(group.androidPermissions.toTypedArray())
                        },
                        enabled = !isGranted
                    ) {
                        Text(if (isGranted) "Granted" else "Request")
                    }
                }
            }
        }
    }
}
