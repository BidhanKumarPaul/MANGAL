package ai.mangal.assistant.ui.models

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ModelManagerScreen() {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Model Manager",
                style = MaterialTheme.typography.titleLarge
            )
            Text(
                text = "Phase 1 empty screen stub. Phase 2 will add GGUF (Qwen 2.5/3, Gemma 3, LFM 2.5 Q4_K_M) and whisper.cpp (tiny/base INT8) Wi-Fi downloads with SHA-256 verification.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
