# Phase 1 Base ProGuard Rules (Expanded in Phase 6 for JNI symbols)
-keep class net.zetetic.database.sqlcipher.** { *; }
-keep class ai.mangal.core.tools.** { *; }
