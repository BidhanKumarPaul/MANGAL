package ai.mangal.core.llm

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

enum class LlmState {
    UNLOADED,
    LOADING,
    READY,
    GENERATING,
    ERROR
}

interface LlmEngine {
    val state: StateFlow<LlmState>
    suspend fun loadModel(ggufFilePath: String, contextSize: Int = 2048, threads: Int = 4): Result<Unit>
    fun generateStream(systemPrompt: String, userPrompt: String): Flow<String>
    suspend fun unloadModel()
}

@Singleton
class LlamaCppEngineImpl @Inject constructor() : LlmEngine {
    private val _state = MutableStateFlow(LlmState.UNLOADED)
    override val state: StateFlow<LlmState> = _state.asStateFlow()

    override suspend fun loadModel(
        ggufFilePath: String,
        contextSize: Int,
        threads: Int
    ): Result<Unit> {
        // Phase 1 scaffold contract — JNI binding wired in Phase 4 after source/AAR verification
        _state.value = LlmState.UNLOADED
        return Result.success(Unit)
    }

    override fun generateStream(systemPrompt: String, userPrompt: String): Flow<String> = flow {
        emit("{\"status\":\"phase_1_scaffold\",\"message\":\"LLM JNI bridge scheduled for Phase 4.\"}")
    }

    override suspend fun unloadModel() {
        _state.value = LlmState.UNLOADED
    }
}
