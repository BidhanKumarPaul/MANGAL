package ai.mangal.core.tools

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import javax.inject.Inject
import javax.inject.Singleton

@Serializable
data class ToolDefinition(
    val name: String,
    val description: String,
    val requiredPermissions: List<String>,
    val parametersSchemaJson: String
)

@Serializable
data class ToolCallRequest(
    val toolName: String,
    val arguments: JsonObject
)

@Serializable
data class ToolExecutionResult(
    val toolName: String,
    val success: Boolean,
    val humanReadableSummary: String,
    val requiresPermissionPrompt: String? = null
)

@Singleton
class ToolRegistry @Inject constructor() {

    private val registeredTools = listOf(
        ToolDefinition(
            name = "set_alarm_or_timer",
            description = "Schedules an alarm or countdown timer via Android AlarmClock / AlarmManager.",
            requiredPermissions = listOf("com.android.alarm.permission.SET_ALARM"),
            parametersSchemaJson = """{"type":"object","properties":{"hour":{"type":"integer"},"minute":{"type":"integer"},"message":{"type":"string"}},"required":["hour","minute"]}"""
        ),
        ToolDefinition(
            name = "create_calendar_event",
            description = "Inserts a local calendar event via Android CalendarContract.",
            requiredPermissions = listOf("android.permission.READ_CALENDAR", "android.permission.WRITE_CALENDAR"),
            parametersSchemaJson = """{"type":"object","properties":{"title":{"type":"string"},"startEpochMs":{"type":"integer"},"durationMinutes":{"type":"integer"}},"required":["title","startEpochMs"]}"""
        ),
        ToolDefinition(
            name = "send_sms_or_place_call",
            description = "Sends an SMS or initiates a phone call after runtime permission check.",
            requiredPermissions = listOf("android.permission.SEND_SMS", "android.permission.CALL_PHONE", "android.permission.READ_CONTACTS"),
            parametersSchemaJson = """{"type":"object","properties":{"action":{"type":"string","enum":["sms","call"]},"recipient":{"type":"string"},"body":{"type":"string"}},"required":["action","recipient"]}"""
        ),
        ToolDefinition(
            name = "open_installed_app",
            description = "Resolves and launches an installed package via Android PackageManager.",
            requiredPermissions = emptyList(),
            parametersSchemaJson = """{"type":"object","properties":{"appName":{"type":"string"}},"required":["appName"]}"""
        ),
        ToolDefinition(
            name = "adjust_device_setting",
            description = "Adjusts volume, flashlight (CameraManager), or opens Settings Panel intent for Wi-Fi/Bluetooth/Brightness.",
            requiredPermissions = emptyList(),
            parametersSchemaJson = """{"type":"object","properties":{"target":{"type":"string","enum":["volume","flashlight","wifi","bluetooth","brightness"]},"state":{"type":"string"}},"required":["target"]}"""
        )
    )

    fun listRegisteredTools(): List<ToolDefinition> = registeredTools
}
