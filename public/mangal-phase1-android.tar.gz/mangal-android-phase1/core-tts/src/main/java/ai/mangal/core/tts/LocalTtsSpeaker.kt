package ai.mangal.core.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

interface LocalTtsSpeaker {
    val isReady: StateFlow<Boolean>
    fun speakOffline(text: String, speechRate: Float = 1.0f, pitch: Float = 1.0f)
    fun stop()
    fun shutdown()
}

@Singleton
class AndroidNativeTtsSpeaker @Inject constructor(
    @ApplicationContext private val context: Context
) : LocalTtsSpeaker, TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private val _isReady = MutableStateFlow(false)
    override val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            _isReady.value = true
        }
    }

    override fun speakOffline(text: String, speechRate: Float, pitch: Float) {
        if (!_isReady.value) return
        tts?.setSpeechRate(speechRate)
        tts?.setPitch(pitch)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mangal_utterance_${System.currentTimeMillis()}")
    }

    override fun stop() {
        tts?.stop()
    }

    override fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        _isReady.value = false
    }
}

@Module
@InstallIn(SingletonComponent::class)
abstract class TtsModule {
    @Binds
    @Singleton
    abstract fun bindLocalTtsSpeaker(impl: AndroidNativeTtsSpeaker): LocalTtsSpeaker
}
